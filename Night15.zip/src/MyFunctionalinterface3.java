//매개변수도 있고, 리턴값이 있는 추상메서드를 가진 함수형 인터페이스
@FunctionalInterface
public interface MyFunctionalinterface3 {
	int method03(int x, int y);
}

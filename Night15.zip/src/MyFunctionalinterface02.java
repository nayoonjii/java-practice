//매개변수는 있고, 리턴이 없는 함수형 인터페이스
@FunctionalInterface
public interface MyFunctionalinterface02 {
	
	public void method(int x);
}


public class Calculator {
		public static int staticMethod(int x, int y) {
			return x+y;
		}//정저메서드
		
		public int instanceMethod(int a, int b) {
			return a+b;
		}//인스턴스 메서드
}

//함수형 인터페이스가 아닌 추상메서드가 한개가 온 일반 인터페이스
public interface MyFunctionalinterface04 {

	void method();
	
}
